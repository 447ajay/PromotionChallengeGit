﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace PromotionChallenge.Service
{
    using Model;

    public class PromotionEngine
    {
        private static List<SKU> skuList;
        private static List<GroupPromotion> GroupPromotion;
        private static List<SinglePromotion> promotions;

        static PromotionEngine()
        {
            skuList = GetAllSKUs();
            promotions = GetAllPromotions();
            GroupPromotion = GetAllGroupPromotions();
        }

        #region Stubs / Code for Setting up SKU and Promotions
        public static List<SinglePromotion> GetAllPromotions()
        {
            return new List<SinglePromotion>
            {
                new SinglePromotion { Qty = 3 , SKUName = 'A' , DiscountedPrice = 130 },
                new SinglePromotion { Qty = 2 , SKUName = 'B' , DiscountedPrice = 45 }
            };
        }

        public static List<GroupPromotion> GetAllGroupPromotions()
        {
            return new List<GroupPromotion>
            {
                new GroupPromotion
                {
                    DiscountedPrice = 30 ,
                    ComboOffers = new List<SinglePromotion>
                    {
                        new SinglePromotion { Qty = 1 , SKUName = 'C' },
                        new SinglePromotion { Qty = 1 , SKUName = 'D' },
                    }
                }
            };
        }

        public static List<SKU> GetAllSKUs()
        {
            return new List<SKU> {
                new SKU { Name = 'A', Price = 50 } ,
                new SKU { Name = 'B', Price = 30 } ,
                new SKU { Name = 'C', Price = 20 } ,
                new SKU { Name = 'D', Price = 15 }
            };
        }

        #endregion Stubs / Code for Setting up SKU and Promotions

        public static double CalculateOrderTotal(List<Order> orders)
        {
            double total = 0;

            Hashtable orderTable = new Hashtable();
            foreach (var order in orders)
            {
                orderTable.Add(order.SKU, order.Qty);
            }

            //Combo Offer can be claimed only for 1 Qty.
            //Combo Offer if availed then an another offer cannot be availed.
            total = CheckForComboOffer(ref orderTable);
            total = CheckForIndividualOffer(ref total, orderTable);

            return total;
        }

        private static double CheckForIndividualOffer(ref double total, Hashtable orderTable)
        {
            foreach (DictionaryEntry entry in orderTable)
            {
                char skuName = (char)entry.Key;
                int orderQty = (int)entry.Value;
                var skuPrice = skuList.FirstOrDefault(x => x.Name == skuName).Price;

                var promoAvailable = promotions.FirstOrDefault(x => x.SKUName == skuName && x.Qty <= orderQty);
                if (promoAvailable != null)
                {
                    var promoQty = orderQty / promoAvailable.Qty;
                    var remainQty = orderQty % promoAvailable.Qty;

                    total += (promoQty * promoAvailable.DiscountedPrice) + (remainQty * skuPrice);
                }
                else
                {
                    total += orderQty * skuPrice;
                }
            }

            return total;
        }

        public static double CheckForComboOffer(ref Hashtable table)
        {
            double total = 0;

            foreach (var item in GroupPromotion)
            {
                bool isApplicable = IsEligibleForComboOffer(table, item);

                //Apply Combo Offer once
                //Call this recursively if multiple times in intended
                if (isApplicable)
                {
                    total = ApplyComboOffer(table, total, item);
                }
            }
            return total;
        }

        private static bool IsEligibleForComboOffer(Hashtable table, GroupPromotion item)
        {
            bool isApplicable = true;
            foreach (var promoItem in item.ComboOffers)
            {
                if (!table.ContainsKey(promoItem.SKUName))
                {
                    isApplicable = false;
                    break;
                }
            }

            return isApplicable;
        }

        private static double ApplyComboOffer(Hashtable table, double total, GroupPromotion item)
        {
            foreach (var promoItem in item.ComboOffers)
            {
                var orderQty = (int)table[promoItem.SKUName];
                if (orderQty >= promoItem.Qty)
                    table[promoItem.SKUName] = orderQty - promoItem.Qty;
                else
                {
                    //Some Items of the Combo not met.
                }
            }
            total += item.DiscountedPrice;
            return total;
        }
    }
}
