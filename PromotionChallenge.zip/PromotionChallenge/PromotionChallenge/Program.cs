﻿using System;
using System.Collections.Generic;

namespace PromotionChallenge
{
    using Model;
    using PromotionChallenge.Service;
    

    class Program
    {
        static void Main(string[] args)
        {
            var orders = new List<Order>
            {
                new Order { Qty = 5 , SKU = 'A'  },
                new Order { Qty = 5 , SKU = 'B'  },
                new Order { Qty = 1 , SKU = 'C'  }
            };

            foreach (var item in orders)
            {
                Console.WriteLine("SKU item {0} with quantity {1}", item.SKU, item.Qty);
            }
            double total = PromotionEngine.CalculateOrderTotal(orders);

            Console.WriteLine("Total Price for the order is = " + total);
        }
    }
}
