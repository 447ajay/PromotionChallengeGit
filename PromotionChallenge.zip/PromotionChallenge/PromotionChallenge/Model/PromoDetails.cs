﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PromotionChallenge.Model
{
    //Base Promotion Class
    public class Promotion
    {
        public double DiscountedPrice { get; set; }
    }


    //Concrete Promotion Class with a single promo offers
    public class SinglePromotion : Promotion
    {
        public int Qty { get; set; }

        public char SKUName { get; set; }
    }


    //Concrete Promotion Class with multiple Single Promo Offers grouped into a Single Combo
    public class GroupPromotion : Promotion
    {
        public List<SinglePromotion> ComboOffers { get; set; }
    }
}
