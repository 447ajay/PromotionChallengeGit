﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PromotionChallenge.Model
{
    //This class keeps track of all items ordered by a Client
    public class Order
    {
        public int Qty { get; set; }

        public char SKU { get; set; }

        public bool PromoApplied { get; set; }
    }
}
