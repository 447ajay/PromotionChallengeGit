﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PromotionChallenge.Model
{
    //This class will provide all Stock Keeping Unit details name and price
    public class SKU
    {
        public char Name { get; set; }

        public double Price { get; set; }
    }
}
